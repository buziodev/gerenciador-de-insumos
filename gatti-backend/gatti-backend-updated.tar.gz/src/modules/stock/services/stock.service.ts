import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '@infrastructure/prisma/prisma.service';
import { CreateStockMovementDto, ListMovementsQueryDto } from '../dtos/stock.dto';

@Injectable()
export class StockService {
  constructor(private prisma: PrismaService) {}

  async createMovement(createMovementDto: CreateStockMovementDto) {
    const supply = await this.prisma.supply.findUnique({
      where: { id: createMovementDto.supplyId },
    });

    if (!supply) {
      throw new NotFoundException(`Suprimento com ID ${createMovementDto.supplyId} não encontrado`);
    }

    const stock = await this.prisma.stock.findUnique({
      where: { supplyId: createMovementDto.supplyId },
    });

    if (!stock) {
      throw new NotFoundException(`Estoque não encontrado para o suprimento ${createMovementDto.supplyId}`);
    }

    // Validar quantidade para saída
    if (
      (createMovementDto.type === 'EXIT' || createMovementDto.type === 'TRANSFER') &&
      stock.quantity < createMovementDto.quantity
    ) {
      throw new BadRequestException(
        `Quantidade insuficiente em estoque. Disponível: ${stock.quantity}`,
      );
    }

    // Criar movimento
    const movement = await this.prisma.stockMovement.create({
      data: createMovementDto,
    });

    // Atualizar quantidade em estoque
    let newQuantity = stock.quantity;
    if (createMovementDto.type === 'ENTRY') {
      newQuantity += createMovementDto.quantity;
    } else if (
      createMovementDto.type === 'EXIT' ||
      createMovementDto.type === 'TRANSFER' ||
      createMovementDto.type === 'LOSS'
    ) {
      newQuantity -= createMovementDto.quantity;
    } else if (createMovementDto.type === 'ADJUSTMENT') {
      newQuantity = createMovementDto.quantity;
    }

    await this.prisma.stock.update({
      where: { supplyId: createMovementDto.supplyId },
      data: { quantity: newQuantity },
    });

    return movement;
  }

  async listMovements(query: ListMovementsQueryDto) {
    const { skip = 0, take = 10, supplyId, type } = query;

    const where: any = {};

    if (supplyId) {
      where.supplyId = supplyId;
    }

    if (type) {
      where.type = type;
    }

    const [data, total] = await Promise.all([
      this.prisma.stockMovement.findMany({
        where,
        skip,
        take,
        include: { supply: true },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.stockMovement.count({ where }),
    ]);

    return {
      data,
      pagination: {
        total,
        skip,
        take,
        pages: Math.ceil(total / take),
      },
    };
  }

  async getStockLevels() {
    return this.prisma.stock.findMany({
      include: { supply: true },
      orderBy: { supply: { name: 'asc' } },
    });
  }

  async getCriticalStock() {
    return this.prisma.stock.findMany({
      where: {
        quantity: {
          lte: this.prisma.stock.fields.minimumLevel,
        },
      },
      include: { supply: true },
    });
  }

  async updateStockLevels(supplyId: string, minimumLevel: number, maximumLevel: number) {
    const stock = await this.prisma.stock.findUnique({
      where: { supplyId },
    });

    if (!stock) {
      throw new NotFoundException(`Estoque não encontrado para o suprimento ${supplyId}`);
    }

    return this.prisma.stock.update({
      where: { supplyId },
      data: { minimumLevel, maximumLevel },
    });
  }
}

import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@infrastructure/prisma/prisma.service';
import { CreatePrinterDto, UpdatePrinterDto, ListPrintersQueryDto } from '../dtos/printer.dto';

@Injectable()
export class PrintersService {
  constructor(private prisma: PrismaService) {}

  async create(createPrinterDto: CreatePrinterDto) {
    return this.prisma.printer.create({
      data: {
        ...createPrinterDto,
      },
      include: {
        sector: true,
        metrics: { take: 10, orderBy: { recordedAt: 'desc' } },
        tonerLevels: { orderBy: { recordedAt: 'desc' } },
      },
    });
  }

  async findAll(query: ListPrintersQueryDto) {
    const { skip = 0, take = 10, status, sectorId, search } = query;

    const where: any = { deletedAt: null };

    if (status) {
      where.status = status;
    }

    if (sectorId) {
      where.sectorId = sectorId;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { hostname: { contains: search, mode: 'insensitive' } },
        { ipAddress: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.printer.findMany({
        where,
        skip,
        take,
        include: {
          sector: true,
          metrics: { take: 1, orderBy: { recordedAt: 'desc' } },
          tonerLevels: { orderBy: { recordedAt: 'desc' } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.printer.count({ where }),
    ]);

    return {
      data,
      pagination: {
        total,
        skip,
        take,
        pages: Math.ceil(total / take),
      },
    };
  }

  async findOne(id: string) {
    const printer = await this.prisma.printer.findUnique({
      where: { id },
      include: {
        sector: true,
        metrics: { orderBy: { recordedAt: 'desc' } },
        tonerLevels: { orderBy: { recordedAt: 'desc' } },
        consumptionHistory: { orderBy: { recordedAt: 'desc' }, take: 30 },
        tonerChanges: { orderBy: { detectedAt: 'desc' }, take: 10 },
        maintenanceHistory: { orderBy: { startDate: 'desc' } },
      },
    });

    if (!printer) {
      throw new NotFoundException(`Impressora com ID ${id} não encontrada`);
    }

    return printer;
  }

  async update(id: string, updatePrinterDto: UpdatePrinterDto) {
    const printer = await this.findOne(id);

    return this.prisma.printer.update({
      where: { id },
      data: updatePrinterDto,
      include: {
        sector: true,
        metrics: { take: 10, orderBy: { recordedAt: 'desc' } },
        tonerLevels: { orderBy: { recordedAt: 'desc' } },
      },
    });
  }

  async remove(id: string) {
    const printer = await this.findOne(id);

    return this.prisma.printer.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
  }

  async findByZabbixHostId(zabbixHostId: string) {
    return this.prisma.printer.findUnique({
      where: { zabbixHostId },
    });
  }

  async getMetrics(id: string, days: number = 30) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    return this.prisma.printerMetric.findMany({
      where: {
        printerId: id,
        recordedAt: { gte: startDate },
      },
      orderBy: { recordedAt: 'asc' },
    });
  }
}
